#任务概述
成功使用 FAST-LIO2 算法处理了包含 Livox Mid-360 激光雷达数据的 rosbag 文件，完成了建图任务，并最终生成了点云地图（PCD 文件）和可视化截图。
#环境信息
​操作系统: Ubuntu 22.04
​ROS 版本: ROS 2 Humble
​硬件数据: Livox Mid-360 录制的 rosbag 数据
工作空间: ~/fast_lio_ws
#完成步骤记录
##环境准备与源码获取
mkdir -p ~/fast_lio_ws/src
cd ~/fast_lio_ws
cd src
git clone https://github.com/hku-mars/FAST_LIO.git --ROS2
git clone https://github.com/hku-mars/ikd-Tree.git
cd ..
rosdep install --from-paths src --ignore-src -y
colcon build
##数据准备
mkdir -p ~/fast_lio_ws/bags
cp ~/Downloads/rosbag_mapping.zip ~/fast_lio_ws/bags/
cd ~/fast_lio_ws/bags
unzip rosbag_mapping.zip
##建图执行
cd ~/fast_lio_ws
source install/setup.bash
ros2 launch fast_lio mapping_mid360.launch.py
cd ~/fast_lio_ws/bags
source ../install/setup.bash
ros2 bag play mapping_0.db3 -r 1.0 
cd ~/fast_lio_ws
source install/setup.bash
ros2 service list | grep -i save
ros2 service call /service_name std_srvs/srv/Trigger
##结果获取
数据播放完成后，在终端1按 Ctrl+C正常终止程序，生成 PCD 文件。
#遇到的问题以及解决方案
##库依赖问题
运行时报错 symbol lookup error: undefined symbol: libusb_set_option
解决方案：
sudo apt update
sudo apt install --upgrade libusb-1.0-0 libusb-1.0-0-dev
sudo ldconfig
sudo apt install cloudcompare -y
##PCD文件无法生成
解决方案：
通过 ROS 服务手动触发保存：ros2 service list | grep -i save
ros2 service call /service_name std_srvs/srv/Trigger
#最终生成的文件
​点云地图: ~/fast_lio_ws/test.pcd

